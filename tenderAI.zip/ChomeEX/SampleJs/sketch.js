

class person {
    constructor(){
        this.hight = 50
        this.genger = "male"
        this.age = 25
        this.name = "Pelle"
    }
}

const testiung = new person();
let personData = new person();
console.log(testiung,personData)

